Here I have created a mini project of ATM using C++.
So this mini project is going to consist of ATM functionalities implimented using OOP concepts.
The functionalities are: 1) Check balance: The user can check the account balance. 2) Cash WithDraw: User can Withdraw cash from the ATM, but the only condition is
user must enter the valid input, like the amount to be withdraw should be less than account balance. 3) User Details: User can see and cross check  details with bank.
4) Update Mobile no. :The user can update mobile number linked to the bank account.
